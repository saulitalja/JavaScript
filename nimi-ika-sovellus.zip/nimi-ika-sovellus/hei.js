var nimi = 1
var nimi2 = 2
var nimi3 = "2+1"
var nimi4 = "Terve maailma"
console.log("Hello world!");
console.log("4");
console.log(4);
console.log(nimi);
console.log(nimi2);
console.log(nimi3);
console.log(2+1);
console.log(nimi+nimi2)
console.log(nimi4)
console.log("Hello " + nimi + " " + nimi2);

for (let i = 0; i < 5; i++) {
    console.log(i);
}

let x = 10;
if (x > 5) {
    console.log("suurempi");
} else {
    console.log("pienempi tai yhtä suuri");
}

function tervehdys() {
    console.log("Hei");
}

function tervehdiNimi(nimi) {
  console.log("Hei, " + nimi + "!");
}

function laskeYhteen(a, b) {
  return a + b;
}

let summa = laskeYhteen(3, 4);
console.log(summa); // tulostaa: 7

tervehdys()
tervehdiNimi("Sauli"); // tulostaa: Hei, Sauli!

let lista = [1, 2, 3];
console.log(lista)

const prompt = require('prompt-sync')();

let nimi5 = prompt("Mikä sinun nimesi on? ");
console.log("Hei, " + nimi5 + "!");


function checkAge() {
	var age = 15
    console.log("The input age:" [age]);
	// Put your code here
	if (age >= 18) {
	    console.log("The user is an adult.");
	} 
	if (0 < age < 18) {
		console.log("The user is not yet an adult.");
	}
	else
	    console.log("Invalid input");
}

