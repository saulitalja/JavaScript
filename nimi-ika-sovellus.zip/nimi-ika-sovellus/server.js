const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

// Body-parser mahdollistaa lomakkeen tietojen lukemisen
app.use(bodyParser.urlencoded({ extended: true }));

// Palauta HTML-lomake
app.get('/', (req, res) => {
  res.send(`
    <form action="/tulosta" method="POST">
      <label for="nimi">Nimi:</label>
      <input type="text" id="nimi" name="nimi" required><br>
      <label for="ika">Ikä:</label>
      <input type="number" id="ika" name="ika" required><br>
      <button type="submit">Lähetä</button>
    </form>
  `);
});

// Käsittele lomakkeen lähetys
app.post('/tulosta', (req, res) => {
  const { nimi, ika } = req.body;
  const paiva = new Date().toLocaleDateString('fi-FI');

  res.send(`
    <h2>Syötit seuraavat tiedot:</h2>
    <p>Nimi: ${nimi}</p>
    <p>Ikä: ${ika}</p>
    <p>Päivämäärä: ${paiva}</p>
    <a href="/">Takaisin</a>
  `);
});

// Käynnistä palvelin
app.listen(port, () => {
  console.log(`Palvelin käynnissä osoitteessa http://localhost:${port}`);
});
