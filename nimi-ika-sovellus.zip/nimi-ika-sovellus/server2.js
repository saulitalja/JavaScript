const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const port = 1111;

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.send(`
    <form action="/tulosta" method="POST">
      <label for="nimi">Nimi:</label>
      <input type="text" id="nimi" name="nimi" required><br>
      <label for="ika">Ikä:</label>
      <input type="number" id="ika" name="ika" required><br>
      <button type="submit">Lähetä</button>
    </form>
  `);
});

/*app.get('/', (req, res) => {
  res.send(`
    <form id="lomake" action="/tulosta" method="POST">
      <label for="nimi">Nimi:</label>
      <input type="text" id="nimi" name="nimi" required><br>
      <label for="ika">Ikä:</label>
      <input type="number" id="ika" name="ika" required><br>
      <button type="submit">Lähetä</button>
    </form>

    <script>
      document.getElementById("lomake").addEventListener("submit", function(event) {
        const nimi = document.getElementById("nimi").value;
        const ika = document.getElementById("ika").value;

        console.log("Syötetty nimi:", nimi);
        console.log("Syötetty ikä:", ika);
        // Huom: tiedot lähtevät silti myös palvelimelle
      });
    </script>
  `);
});*/


app.post('/tulosta', (req, res) => {
  const { nimi, ika } = req.body;
  const paiva = new Date().toLocaleDateString('fi-FI');
  const teksti = `Nimi: ${nimi}, Ikä: ${ika}, Päivämäärä: ${paiva}`;

  // Tulosta konsoliin
  console.log(teksti);

  // Kirjoita tiedostoon (lisää riveittäin)
/*  fs.appendFile('tulokset.txt', teksti + '\n', (err) => {
    if (err) {
      console.error('Tiedostoon kirjoitus epäonnistui:', err);
    }
  });*/

  // Vastaa selaimelle
  res.send(`
    <h2>Syötit seuraavat tiedot:</h2>
    <p>${teksti}</p>
    <a href="/">Takaisin</a>
  `);
});

app.listen(port, () => {
  console.log(`Palvelin käynnissä osoitteessa http://localhost:${port}`);
});
